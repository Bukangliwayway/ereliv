<?php require_once("../backend/session_faculty.php"); ?>

<style>
  :root {
    /* Define the --highcharts-background-color variable */
    --highcharts-background-color: #ffffff;
    /* Set your desired background color here */
  }
</style>
<div class="d-flex flex-row align-items-center justify-content-center px-5 py-3">
  <div class="d-flex flex-column align-items-center gap-3 shadow p-5 py-3">
    <h2 class="m-0  p-0 text-center sapphire-blue-text text-capitalize mb-0"><i class="bi bi-person-fill"></i>
      <?php echo $_SESSION['username']; ?>
    </h2>
    <p class="text-muted text-center text-capitalize p-2 border border-primary rounded " style="width:40ch">Welcome back! Here's your data-driven
      analytics to make informed decisions. Stay empowered with valuable insights. </p>
  </div>
</div>

<div class="row mx-auto d-flex flex-wrap justify-content-center  align-items-center gap-3 mt-3">

  <div id="heatmapContainer" class="custom-chart-container col-11 shadow-sm p-3"></div>
  <div id="programBarChart" class="custom-chart-container col-11 shadow-sm p-3"></div>
  <div id="statusesPieChart" class="custom-chart-container col-5 shadow-sm p-3"></div>
  <div id="classificationsPieChart" class="custom-chart-container col-5 shadow-sm p-3"></div>
</div>

<script>
  function generateRandomData(rows, columns) {
    const data = [];
    for (let i = 1; i < rows; i++) {
      const row = [];
      for (let j = 1; j < columns; j++) {
        row.push(Math.floor(Math.random() * 5)); // Random value from 0 to 4
      }
      data.push(row);
    }
    return data;
  }

  // Number of rows and columns in the heatmap (customize as needed)
  const rows = 7; // Represents days of the week (Sunday to Saturday)
  const columns = 53; // Represents weeks in a year (approximately)

  // Generate random data for the heatmap
  const heatmapData = generateRandomData(rows, columns);

  // Mark specific dates in the heatmap data
  // In this example, we mark 2 in July 20 (row index 1) and 3 in July 21 (row index 2)
  heatmapData[1][29] = 2; // July 20
  heatmapData[2][30] = 3; // July 21

  // Highcharts configuration for the GitHub-style heatmap chart
  const heatmapOptions = {
    chart: {
      type: 'heatmap',
      marginTop: 40,
      marginBottom: 80,
      plotBorderWidth: 1,
      style: {
        fontFamily: 'Arial, sans-serif',
      },
    },
    title: {
      text: 'Your Weekly Contributions',
    },
    xAxis: {
      categories: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
      title: {
        text: 'Day of the Week',
      },
      tickInterval: 1,
    },
    yAxis: {
      categories: Array.from({ length: 53 }, (_, i) => i + 1), // Weeks from 1 to 53
      title: {
        text: 'Week of the Year',
      },
    },
    colorAxis: {
      min: 0,
      max: 4,
      // Define your own color scale here using stops or a color range similar to GitHub's
      stops: [
        [0, '#ebedf0'],
        [0.25, '#9be9a8'],
        [0.5, '#40c463'],
        [0.75, '#30a14e'],
        [1, '#216e39'],
      ],
    },
    legend: {
      align: 'right',
      layout: 'vertical',
      margin: 0,
      verticalAlign: 'top',
      y: 25,
      symbolHeight: 280,
    },
    tooltip: {
      formatter: function () {
        return `<b>Week ${this.point.y}</b><br>${this.point.category}: ${this.point.value} contributions`;
      },
    },
    series: [
      {
        data: heatmapData,
        dataLabels: {
          enabled: true,
          color: '#000000',
        },
      },
    ],
  };

  // Create the GitHub-style heatmap chart using the configuration options
  Highcharts.chart('heatmapContainer', heatmapOptions);














  // initially start it
  updateProgramBarChart();
  updateStatusesPieChart();
  updateClassificationsPieChart();

  document
    .querySelector("#homeBtn")
    .addEventListener("click", function (event) {
      if (event.isTrusted) {
        updateProgramBarChart();
        updateStatusesPieChart();
        updateClassificationsPieChart();
          Highcharts.chart('heatmapContainer', heatmapOptions);

      }
    });
  // Update research list function
  async function updateProgramBarChart() {
    try {
      // Fetch the CSRF token from the server
      const response = await fetch("../backend/getcsrftoken.php");
      if (response.ok) {
        const csrfToken = await response.text();

        // Prepare the request data
        const requestData = {
          userID: '<?php echo $_SESSION['userID']; ?>',
          type: "faculty",
          csrf_token: csrfToken,
        };

        // Make the request to load faculty accounts
        const ajaxRequest = $.ajax({
          url: "../backend/updateprogrambarchart.php",
          type: "POST",
          data: requestData,
        });

        ajaxRequest.done(function (response) {
          const programNames = [];
          const programCardinalities = [];

          // Iterate through the data and extract program names and cardinalities
          response.forEach((item) => {
            programNames.push(item.programName);
            programCardinalities.push(item.programCardinality);
          });


          const customColors = ['#ff6347', '#ffa500', '#32cd32', '#4169e1', '#8a2be2'];


          // Create the Highcharts bar chart
          Highcharts.chart('programBarChart', {
            chart: {
              type: 'bar',
              backgroundColor: '#ffffff',

            },
            title: {
              text: 'Researches per Programs',
              style: {
                color: '#333333', // Set the font color to dark gray (you can change it to any color you prefer)
                fontWeight: 'bold' // You can also customize other font styles here if needed
              }
            },
            xAxis: {
              categories: programNames,
              title: {
                text: 'Programs',
                style: {
                  color: '#333333', // Set the font color to dark gray (you can change it to any color you prefer)
                  fontWeight: 'bold' // You can also customize other font styles here if needed
                }
              }
            },
            yAxis: {
              title: {
                text: 'Researches Count',
                style: {
                  color: '#333333', // Set the font color to dark gray (you can change it to any color you prefer)
                  fontWeight: 'bold' // You can also customize other font styles here if needed
                }
              },
              tickInterval: 1,
              labels: {
                // Use the formatter function to display only integers on the y-axis
                formatter: function () {
                  return this.value.toFixed(0);
                }
              },
            },
            plotOptions: {
              bar: {
                pointPadding: 0.0, // Adjust the pointPadding to minimize the space between bars
                groupPadding: 0.1, // Adjust the groupPadding to minimize the space between groups
              }
            },
            series: [{
              name: 'Research',
              data: programCardinalities
            }]
          });
        });

        ajaxRequest.fail(function (xhr, status, error) {
          console.log(error);
        });
      } else {
        // Unable to fetch CSRF token, handle the error
        console.error("Error fetching CSRF token:", response.status);
        displayToastr("error", "An error occurred. Please try again.");
      }
    } catch (error) {
      // General error occurred, handle it
      console.error("Error:", error);
      displayToastr("error", "An error occurred. Please try again.");
    }
  }

  // Update research list function
  async function updateStatusesPieChart() {
    try {
      // Fetch the CSRF token from the server
      const response = await fetch("../backend/getcsrftoken.php");
      if (response.ok) {
        const csrfToken = await response.text();

        // Prepare the request data
        const requestData = {
          userID: '<?php echo $_SESSION['userID']; ?>',
          type: "faculty",
          csrf_token: csrfToken,
        };

        // Make the request to load faculty accounts
        const ajaxRequest = $.ajax({
          url: "../backend/updatestatusespiechart.php",
          type: "POST",
          data: requestData,
        });

        ajaxRequest.done(function (response) {
          console.log(response);

          const pieChartData = response.map((data) => {
            return {
              name: data.researchstatus,
              y: data.num_of_research,
            };
          });

          const customColors = ['#ff6347', '#ffa500', '#32cd32', '#4169e1', '#8a2be2'];
          // Create the pie chart
          Highcharts.chart('statusesPieChart', {
            chart: {
              type: 'pie'
            },
            title: {
              text: 'Research Status Distribution'
            },
            plotOptions: {
              pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                colors: customColors,
                dataLabels: {
                  enabled: true,
                  format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                }
              }
            },
            series: [
              {
                name: 'Research Status',
                data: pieChartData
              }
            ]
          });
        });

        ajaxRequest.fail(function (xhr, status, error) {
          console.log(error);
        });
      } else {
        // Unable to fetch CSRF token, handle the error
        console.error("Error fetching CSRF token:", response.status);
        displayToastr("error", "An error occurred. Please try again.");
      }
    } catch (error) {
      // General error occurred, handle it
      console.error("Error:", error);
      displayToastr("error", "An error occurred. Please try again.");
    }
  }

  // Update research list function
  async function updateClassificationsPieChart() {
    try {
      // Fetch the CSRF token from the server
      const response = await fetch("../backend/getcsrftoken.php");
      if (response.ok) {
        const csrfToken = await response.text();

        // Prepare the request data
        const requestData = {
          userID: '<?php echo $_SESSION['userID']; ?>',
          type: "faculty",
          csrf_token: csrfToken,
        };

        // Make the request to load faculty accounts
        const ajaxRequest = $.ajax({
          url: "../backend/updateclassificationspiechart.php",
          type: "POST",
          data: requestData,
        });

        ajaxRequest.done(function (response) {
          console.log(response);

          const pieChartData = response.map((data) => {
            return {
              name: data.researchclassification,
              y: data.num_of_research,
            };
          });

          const customColors = ['#ff6347', '#ffa500', '#32cd32', '#4169e1', '#8a2be2'];
          // Create the pie chart
          Highcharts.chart('classificationsPieChart', {
            chart: {
              type: 'pie'
            },
            title: {
              text: 'Research Classification Distribution'
            },
            plotOptions: {
              pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                colors: customColors,
                dataLabels: {
                  enabled: true,
                  format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                }
              }
            },
            series: [
              {
                name: 'Research Classification',
                data: pieChartData
              }
            ]
          });
        });

        ajaxRequest.fail(function (xhr, status, error) {
          console.log(error);
        });
      } else {
        // Unable to fetch CSRF token, handle the error
        console.error("Error fetching CSRF token:", response.status);
        displayToastr("error", "An error occurred. Please try again.");
      }
    } catch (error) {
      // General error occurred, handle it
      console.error("Error:", error);
      displayToastr("error", "An error occurred. Please try again.");
    }
  }


</script>